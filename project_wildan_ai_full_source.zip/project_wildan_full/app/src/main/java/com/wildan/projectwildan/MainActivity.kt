package com.wildan.projectwildan

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "🤖 Project Wildan"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Robot AI online • Chat • Suara • Floating Window"
            textSize = 15f; setTextColor(0xFFD1D5DB.toInt())
            gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(20))
        }
        val endpoint = EditText(this).apply {
            hint = "URL backend HTTPS, contoh https://domainkamu.com/chat"
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9CA3AF.toInt())
            setSingleLine(true)
        }
        val save = Button(this).apply { text = "Simpan URL backend" }
        val start = Button(this).apply { text = "Aktifkan / Tampilkan Robot" }
        root.addView(title); root.addView(desc); root.addView(endpoint)
        root.addView(save); root.addView(start)
        setContentView(root)
        endpoint.setText(getSharedPreferences("wildan", MODE_PRIVATE).getString("endpoint", ""))
        save.setOnClickListener {
            val value = endpoint.text.toString().trim()
            getSharedPreferences("wildan", MODE_PRIVATE).edit().putString("endpoint", value).apply()
            Toast.makeText(this, "URL backend disimpan", Toast.LENGTH_SHORT).show()
        }
        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingService::class.java))
                finish()
            }
        }
    }
}
