package com.wildan.projectwildan

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.RecognitionListener
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class FloatingService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var logView: TextView? = null
    private var inputView: EditText? = null
    private var speech: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        showBubble()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            val result = tts?.setLanguage(Locale("id", "ID"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.getDefault()
            }
        }
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "🤖"; textSize = 27f; gravity = Gravity.CENTER
            setBackgroundColor(0xFF2563EB.toInt()); setTextColor(0xFFFFFFFF.toInt())
            elevation = dp(8).toFloat()
        }
        val params = WindowManager.LayoutParams(
            dp(62), dp(62), overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(180) }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)>dp(5) || kotlin.math.abs(dy)>dp(5)) moved=true
                        params.x=ox+dx; params.y=oy+dy
                        try { wm.updateViewLayout(b, params) } catch (_: Exception) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) showPanel(); return true }
                }
                return false
            }
        })
        bubble = b
        wm.addView(b, params)
    }

    private fun showPanel() {
        if (panel != null) { removePanel(); return }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFF111827.toInt())
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "Project Wildan AI"; textSize = 18f; setTextColor(0xFFFFFFFF.toInt()) }
        val close = Button(this).apply { text = "Tutup"; setOnClickListener { removePanel() } }
        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f)); header.addView(close)
        val log = TextView(this).apply {
            text = "Wildan AI: Halo! Tanyakan apa saja. Pastikan URL backend AI sudah disetel di aplikasi.\\n"
            textSize = 14f; setTextColor(0xFFE5E7EB.toInt()); setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        logView = log
        val scroll = ScrollView(this).apply { addView(log) }
        val input = EditText(this).apply {
            hint = "Tulis pesan..."; setSingleLine(false); setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9CA3AF.toInt())
        }
        inputView = input
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val send = Button(this).apply { text = "Kirim" }
        val mic = Button(this).apply { text = "🎙" }
        val speak = Button(this).apply { text = "🔊" }
        row.addView(send, LinearLayout.LayoutParams(0, dp(48), 1f)); row.addView(mic); row.addView(speak)
        send.setOnClickListener {
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) { input.setText(""); askAI(q) }
        }
        mic.setOnClickListener { listen() }
        speak.setOnClickListener {
            val last = log.text.toString().substringAfterLast("Wildan AI: ", "").trim()
            if (last.isNotBlank() && ttsReady) tts?.speak(last, TextToSpeech.QUEUE_FLUSH, null, "wildan-answer")
            else Toast.makeText(this, "Belum ada jawaban untuk dibacakan.", Toast.LENGTH_SHORT).show()
        }
        outer.addView(header)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(input)
        outer.addView(row)
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.9).toInt(), dp(440), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        panel = outer
        wm.addView(outer, params)
    }

    private fun append(text: String) {
        logView?.append("\\n$text\\n")
    }

    private fun askAI(message: String) {
        val endpoint = getSharedPreferences("wildan", MODE_PRIVATE).getString("endpoint", "")?.trim().orEmpty()
        append("Kamu: $message")
        if (endpoint.isBlank() || !endpoint.startsWith("https://")) {
            append("Wildan AI: URL backend HTTPS belum diatur. Buka aplikasi utama dan masukkan URL backend AI.")
            return
        }
        append("Wildan AI: Sedang berpikir...")
        scope.launch {
            val answer = withContext(Dispatchers.IO) {
                try {
                    val payload = JSONObject().put("message", message)
                    val request = Request.Builder().url(endpoint)
                        .post(payload.toString().toRequestBody(jsonType))
                        .header("Accept", "application/json").build()
                    http.newCall(request).execute().use { response ->
                        val body = response.body?.string().orEmpty()
                        if (!response.isSuccessful) throw Exception("Server HTTP ${response.code}")
                        val obj = JSONObject(body)
                        obj.optString("reply").ifBlank { throw Exception("JSON server harus memiliki field 'reply'") }
                    }
                } catch (e: Exception) {
                    "Gagal menghubungi backend: ${e.message ?: "periksa koneksi dan URL"}"
                }
            }
            append("Wildan AI: $answer")
            if (ttsReady && !answer.startsWith("Gagal menghubungi")) {
                tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "wildan-answer")
            }
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Pengenalan suara tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show(); return
        }
        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { Toast.makeText(this@FloatingService, "Suara tidak dikenali. Coba lagi.", Toast.LENGTH_SHORT).show() }
            override fun onResults(results: android.os.Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) {
                    inputView?.setText(text)
                    askAI(text)
                }
            }
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Bicaralah kepada Project Wildan")
        }
        speech?.startListening(i)
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; logView = null; inputView = null
    }

    override fun onDestroy() {
        removePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        speech?.destroy()
        tts?.shutdown()
        scope.cancel()
        http.dispatcher.cancelAll()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
