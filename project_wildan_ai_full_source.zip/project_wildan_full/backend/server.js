// Contoh backend Node.js minimal (kerangka; belum memanggil penyedia AI).
// npm init -y && npm install express
// Jalankan hanya di lingkungan development; produksi wajib HTTPS/proxy,
// autentikasi, rate limit, dan integrasi model AI yang sesungguhnya.
const express = require("express");
const app = express();
app.use(express.json({ limit: "20kb" }));

app.post("/chat", async (req, res) => {
  const message = String(req.body?.message || "").trim();
  if (!message) return res.status(400).json({ error: "message wajib diisi" });

  // Ganti bagian ini dengan pemanggilan API penyedia AI dari server.
  // Ambil secret dari environment, misalnya process.env.AI_API_KEY.
  // Jangan pernah kirim API key ke aplikasi Android.
  return res.status(501).json({
    error: "Backend belum terhubung ke penyedia AI.",
    hint: "Implementasikan panggilan model AI di server dan balas { reply: \"...\" }."
  });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Backend starter listening on ${port}`));
