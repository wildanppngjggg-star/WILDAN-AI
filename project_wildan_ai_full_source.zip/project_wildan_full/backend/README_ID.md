# Backend AI HTTPS — kontrak API

Aplikasi Android mengirim POST JSON ke URL yang kamu masukkan pada layar utama:

`{"message":"Halo, siapa kamu?"}`

Backend harus mengembalikan JSON:

`{"reply":"Halo! Aku Project Wildan AI."}`

Wajib gunakan HTTPS dan simpan API key penyedia AI hanya di server, bukan di APK. Contoh berikut adalah kerangka Node.js; tambahkan autentikasi, pembatasan pemakaian, dan integrasi penyedia AI pilihanmu sebelum dipublikasikan.
